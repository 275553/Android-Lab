package com.lab7.zad1

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.content.Intent
import android.view.View
import android.widget.EditText
import android.widget.TextView
import com.lab7.zad1.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    fun submit (view: View){
        val imie = findViewById<EditText>(R.id.imie)
        val wiek = findViewById<EditText>(R.id.wiek)

        var i : String = imie.text.toString()
        var w : String = wiek.text.toString()

        var intent = Intent(this@MainActivity, SecondActivity::class.java)

        intent.putExtra("nam",i)
        intent.putExtra("age",w)

        var t = findViewById<TextView>(R.id.textView4)
        //t.text = i +" ; " + w
        startActivity(intent)
    }

}