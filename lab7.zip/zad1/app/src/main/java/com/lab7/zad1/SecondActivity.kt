package com.lab7.zad1

import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class SecondActivity : AppCompatActivity() {


    lateinit var txt: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_second)


        var txt = findViewById<TextView>(R.id.textView3)

        var imie : String = intent.getStringExtra("nam").toString()
        var wiek : String = intent.getStringExtra("age").toString()


        txt.text = "imie: $imie oraz $wiek"
    }
}