package com.lab5.bmi

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Spinner
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.security.SecureRandom

class PasswordActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_password)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    //I tak komputer kwantowy złamie wszystkie te hasła:(

    private val secureRandom = SecureRandom()

    fun generuj (view: View) {
        val length = findViewById<EditText>(R.id.length).text.toString().toString().toInt()

        val znaczki =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()-_=+[]{}<>?"
        val haslo = buildString {
            repeat(length) {
                append(znaczki[secureRandom.nextInt(znaczki.length)])
            }
        }

        findViewById<EditText>(R.id.psswd).setText(haslo)
    }

    fun conv(view: View){
        startActivity(Intent(this, MainUnit::class.java))
        finish()
    }
    fun bmi(view: View){
        startActivity(Intent(this, ReadyActivity::class.java))
        finish()
    }

}