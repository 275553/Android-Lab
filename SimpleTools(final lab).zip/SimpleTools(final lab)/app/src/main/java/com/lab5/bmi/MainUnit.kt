package com.lab5.bmi

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView

class MainUnit : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_unit)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

// spać mi się chce

    val units = listOf(
        "m", "dm", "cm", "mm", "µm", "dam", "hm", "km"
    )

        val From_unit = findViewById<Spinner>(R.id.from_unit)
        val To_unit = findViewById<Spinner>(R.id.to_unit)

    val adapter = ArrayAdapter(
        this,
        android.R.layout.simple_spinner_item,
        units
    )
        adapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        From_unit.adapter = adapter
        To_unit.adapter = adapter
}
    val factors = mapOf(
        "µm" to 1e-6,
        "mm" to 1e-3,
        "cm" to 1e-2,
        "dm" to 1e-1,
        "m"  to 1.0,
        "dam" to 1e1,
        "hm" to 1e2,
        "km" to 1e3
    )
    fun konwertuj(view: View)
    {
        val From_unit = findViewById<Spinner>(R.id.from_unit)
        val from = From_unit.selectedItem.toString()
        val To_unit = findViewById<Spinner>(R.id.to_unit)
        val to = To_unit.selectedItem.toString()

        val from_value = findViewById<EditText>(R.id.from_value).text.toString().toDouble()
        val startval = from_value * factors[from]!!
        val resultval = startval / factors[to]!!

        val to_value = findViewById<TextView>(R.id.to_value)
        to_value.text = resultval.toString()
    }
    fun pss(view: View){
        startActivity(Intent(this, PasswordActivity::class.java))
        finish()
    }
    fun bmi(view: View){
        startActivity(Intent(this, ReadyActivity::class.java))
        finish()
    }
}